{{- define "app.istio-gateway" -}}
{{- if .Values.routing.istio.enabled }}
apiVersion: networking.istio.io/v1
kind: Gateway
metadata:
  name: {{ include "app.fullname" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
  {{- with .Values.routing.istio.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  selector:
    {{- toYaml .Values.routing.istio.gateway.selector | nindent 4 }}
  servers:
    - hosts:
        {{- range .Values.routing.hosts }}
        - {{ . | quote }}
        {{- end }}
      port:
        name: {{ .Values.service.name | default "http" }}
        number: {{ .Values.service.port | default "80" }}
        protocol: HTTP
{{- end }}

{{- end -}}
