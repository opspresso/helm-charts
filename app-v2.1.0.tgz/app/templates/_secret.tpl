{{- define "app.secret" -}}
{{- if and .Values.secret.enabled .Values.secret.data }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "app.fullname" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
  annotations:
    argocd.argoproj.io/sync-wave: "-1"
type: Opaque
data:
  {{- range $key, $value := .Values.secret.data }}
  {{ $key }}: {{ $value | quote }}
  {{- end }}
{{- end }}

{{- end -}}
