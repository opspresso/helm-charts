{{- define "app.serviceaccount" -}}
{{- if or .Values.serviceAccount.create .Values.irsa.enabled }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "app.serviceAccountName" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
  {{- if or .Values.irsa.enabled .Values.serviceAccount.annotations }}
  annotations:
    {{- if .Values.irsa.enabled }}
    eks.amazonaws.com/role-arn: {{ .Values.irsa.roleArn }}
    {{- end }}
    {{- with .Values.serviceAccount.annotations }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end }}

{{- end -}}
