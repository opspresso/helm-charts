{{- define "app.pdb" -}}
{{- if .Values.pdb.enabled }}
{{- $min := hasKey .Values.pdb "minAvailable" }}
{{- $max := hasKey .Values.pdb "maxUnavailable" }}
{{- if and $min $max }}
{{- fail "pdb accepts minAvailable or maxUnavailable, not both." }}
{{- end }}
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ include "app.fullname" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
spec:
  {{- if $min }}
  minAvailable: {{ .Values.pdb.minAvailable }}
  {{- else }}
  maxUnavailable: {{ $max | ternary .Values.pdb.maxUnavailable 1 }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "app.selectorLabels" . | nindent 6 }}
{{- end }}

{{- end -}}
