{{- define "app.service" -}}
{{- if .Values.service.enabled }}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "app.fullname" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
  {{- with .Values.service.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - name: {{ .Values.service.name }}
      port: {{ .Values.service.port }}
      protocol: {{ .Values.service.protocol }}
      targetPort: {{ .Values.service.name }}
    {{- with .Values.service.extraPorts }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  selector:
    {{- include "app.selectorLabels" . | nindent 4 }}
{{- end }}

{{- end -}}
