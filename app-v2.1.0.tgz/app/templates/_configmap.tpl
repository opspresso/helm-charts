{{- define "app.configmap" -}}
{{- if and .Values.configmap.enabled .Values.configmap.data }}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "app.fullname" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
  annotations:
    argocd.argoproj.io/sync-wave: "-1"
data:
  {{- range $key, $value := .Values.configmap.data }}
  {{ $key }}: {{ $value | quote }}
  {{- end }}
{{- end }}

{{- end -}}
