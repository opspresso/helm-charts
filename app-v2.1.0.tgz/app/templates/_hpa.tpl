{{- define "app.hpa" -}}
{{- if .Values.autoscaling.enabled }}
{{- if not .Values.autoscaling.metrics }}
{{- fail "autoscaling.enabled requires at least one metric in autoscaling.metrics." }}
{{- end }}
{{- if gt (int .Values.autoscaling.minReplicas) (int .Values.autoscaling.maxReplicas) }}
{{- fail "autoscaling.minReplicas must not exceed autoscaling.maxReplicas." }}
{{- end }}
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ include "app.fullname" . }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
spec:
  scaleTargetRef:
    {{- if eq .Values.controller.kind "Rollout" }}
    apiVersion: argoproj.io/v1alpha1
    kind: Rollout
    {{- else }}
    apiVersion: apps/v1
    kind: Deployment
    {{- end }}
    name: {{ include "app.fullname" . }}
  minReplicas: {{ .Values.autoscaling.minReplicas }}
  maxReplicas: {{ .Values.autoscaling.maxReplicas }}
  {{- with .Values.autoscaling.metrics }}
  metrics:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.autoscaling.behavior }}
  behavior:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}

{{- end -}}
