{{- define "app.rbac" -}}
{{- if .Values.rbac.create }}
{{- if not (or .Values.serviceAccount.create .Values.irsa.enabled .Values.serviceAccount.name) }}
{{- fail "rbac.create requires a ServiceAccount: set serviceAccount.create, serviceAccount.name or irsa.enabled." }}
{{- end }}
{{- $kind := ternary "Role" "ClusterRole" (eq .Values.rbac.namespaced true) }}
apiVersion: rbac.authorization.k8s.io/v1
kind: {{ $kind }}
metadata:
  name: {{ include "app.fullname" . }}
  {{- if .Values.rbac.namespaced }}
  namespace: {{ include "app.namespace" . }}
  {{- end }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
rules:
{{- with .Values.rbac.rules }}
{{ toYaml . | indent 2 }}
{{- end }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: {{ $kind }}Binding
metadata:
  name: {{ include "app.fullname" . }}
  {{- if .Values.rbac.namespaced }}
  namespace: {{ include "app.namespace" . }}
  {{- end }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
subjects:
  - kind: ServiceAccount
    name: {{ include "app.serviceAccountName" . }}
    namespace: {{ include "app.namespace" . }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: {{ $kind }}
  name: {{ include "app.fullname" . }}
{{- end }}

{{- end -}}
