{{- define "app.ingress" -}}
{{- if .Values.routing.ingress.enabled }}
{{- $fullName := include "app.fullname" . -}}
{{- $servicePort := .Values.service.port -}}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ $fullName }}
  namespace: {{ include "app.namespace" . }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
  {{- with .Values.routing.ingress.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- with .Values.routing.ingress.className }}
  ingressClassName: {{ . }}
  {{- end }}
  {{- if .Values.routing.ingress.tls }}
  tls:
    {{- range .Values.routing.ingress.tls }}
    - hosts:
        {{- range .hosts }}
        - {{ . | quote }}
        {{- end }}
      secretName: {{ .secretName }}
    {{- end }}
  {{- end }}
  rules:
    {{- range .Values.routing.hosts }}
    - host: {{ . | quote }}
      http:
        paths:
          - path: {{ $.Values.routing.path }}
            pathType: {{ $.Values.routing.pathType }}
            backend:
              service:
                name: {{ $fullName }}
                port:
                  number: {{ $servicePort }}
    {{- end }}
{{- end }}

{{- end -}}
